﻿namespace 农林信息系统
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ToolStripMenuItemShujuchuangkou = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemZhuangtixinxi = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemZhubeishiyixing = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemTuranqinranxing = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemDaqiwuranjiance = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemShuiwenfenxi = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBangzhuwenjian = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemJianyi = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemZhongzhijianyi = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItemBangzhushipin = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.axMapControlYingyan = new ESRI.ArcGIS.Controls.AxMapControl();
            this.groupBoxJichumianban = new System.Windows.Forms.GroupBox();
            this.PanelJichutuceng = new System.Windows.Forms.Panel();
            this.ButtonDaolu = new System.Windows.Forms.Button();
            this.ButtonXingzhengfanwei = new System.Windows.Forms.Button();
            this.ButtonGuanlituceng = new System.Windows.Forms.Button();
            this.panelShuqian = new System.Windows.Forms.Panel();
            this.buttonYichusuoxuan = new System.Windows.Forms.Button();
            this.buttonYichuquanbu = new System.Windows.Forms.Button();
            this.buttonDingwei = new System.Windows.Forms.Button();
            this.listBoxShuqian = new System.Windows.Forms.ListBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.axMapControlZhu = new ESRI.ArcGIS.Controls.AxMapControl();
            this.axLicenseControl = new ESRI.ArcGIS.Controls.AxLicenseControl();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.PanelJiangshuichaxun = new System.Windows.Forms.Panel();
            this.PanelHeliuxianzhuang = new System.Windows.Forms.Panel();
            this.PanelZhibeifenbu = new System.Windows.Forms.Panel();
            this.buttonQihouxinxi = new System.Windows.Forms.Button();
            this.buttonHeliufenbu = new System.Windows.Forms.Button();
            this.buttonFugaishuju = new System.Windows.Forms.Button();
            this.buttonJiangshuichaxun = new System.Windows.Forms.Button();
            this.buttonHeliuxianzhuang = new System.Windows.Forms.Button();
            this.ButtonZhibeifenbu = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControlYingyan)).BeginInit();
            this.groupBoxJichumianban.SuspendLayout();
            this.PanelJichutuceng.SuspendLayout();
            this.panelShuqian.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControlZhu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.PanelJiangshuichaxun.SuspendLayout();
            this.PanelHeliuxianzhuang.SuspendLayout();
            this.PanelZhibeifenbu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.Controls.Add(this.splitContainer1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1528, 1055);
            this.panel1.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(13, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.splitContainer1.Panel1.Controls.Add(this.panel3);
            this.splitContainer1.Panel1.Controls.Add(this.panel2);
            this.splitContainer1.Panel1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1502, 1051);
            this.splitContainer1.SplitterDistance = 78;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(0, 2, 0, 2);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemShujuchuangkou,
            this.ToolStripMenuItemZhuangtixinxi,
            this.ToolStripMenuItemBangzhuwenjian});
            this.menuStrip1.Location = new System.Drawing.Point(454, 10);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(372, 32);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // ToolStripMenuItemShujuchuangkou
            // 
            this.ToolStripMenuItemShujuchuangkou.BackColor = System.Drawing.Color.Transparent;
            this.ToolStripMenuItemShujuchuangkou.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1});
            this.ToolStripMenuItemShujuchuangkou.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ToolStripMenuItemShujuchuangkou.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemShujuchuangkou.Name = "ToolStripMenuItemShujuchuangkou";
            this.ToolStripMenuItemShujuchuangkou.Size = new System.Drawing.Size(122, 28);
            this.ToolStripMenuItemShujuchuangkou.Text = "数据窗口";
            // 
            // ToolStripMenuItemZhuangtixinxi
            // 
            this.ToolStripMenuItemZhuangtixinxi.BackColor = System.Drawing.Color.Transparent;
            this.ToolStripMenuItemZhuangtixinxi.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemZhubeishiyixing,
            this.ToolStripMenuItemTuranqinranxing,
            this.ToolStripMenuItemDaqiwuranjiance,
            this.ToolStripMenuItemShuiwenfenxi});
            this.ToolStripMenuItemZhuangtixinxi.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ToolStripMenuItemZhuangtixinxi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemZhuangtixinxi.Name = "ToolStripMenuItemZhuangtixinxi";
            this.ToolStripMenuItemZhuangtixinxi.Size = new System.Drawing.Size(122, 28);
            this.ToolStripMenuItemZhuangtixinxi.Text = "专题信息";
            // 
            // ToolStripMenuItemZhubeishiyixing
            // 
            this.ToolStripMenuItemZhubeishiyixing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(142)))), ((int)(((byte)(97)))));
            this.ToolStripMenuItemZhubeishiyixing.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemZhubeishiyixing.Name = "ToolStripMenuItemZhubeishiyixing";
            this.ToolStripMenuItemZhubeishiyixing.Size = new System.Drawing.Size(230, 28);
            this.ToolStripMenuItemZhubeishiyixing.Text = "植被适宜性";
            this.ToolStripMenuItemZhubeishiyixing.Click += new System.EventHandler(this.植被适宜性ToolStripMenuItem_Click);
            // 
            // ToolStripMenuItemTuranqinranxing
            // 
            this.ToolStripMenuItemTuranqinranxing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(142)))), ((int)(((byte)(97)))));
            this.ToolStripMenuItemTuranqinranxing.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemTuranqinranxing.Name = "ToolStripMenuItemTuranqinranxing";
            this.ToolStripMenuItemTuranqinranxing.Size = new System.Drawing.Size(230, 28);
            this.ToolStripMenuItemTuranqinranxing.Text = "土壤侵蚀性";
            this.ToolStripMenuItemTuranqinranxing.Click += new System.EventHandler(this.土壤侵蚀性ToolStripMenuItem_Click);
            // 
            // ToolStripMenuItemDaqiwuranjiance
            // 
            this.ToolStripMenuItemDaqiwuranjiance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(142)))), ((int)(((byte)(97)))));
            this.ToolStripMenuItemDaqiwuranjiance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemDaqiwuranjiance.Name = "ToolStripMenuItemDaqiwuranjiance";
            this.ToolStripMenuItemDaqiwuranjiance.Size = new System.Drawing.Size(230, 28);
            this.ToolStripMenuItemDaqiwuranjiance.Text = "大气污染检测";
            this.ToolStripMenuItemDaqiwuranjiance.Click += new System.EventHandler(this.大气污染检测ToolStripMenuItem_Click);
            // 
            // ToolStripMenuItemShuiwenfenxi
            // 
            this.ToolStripMenuItemShuiwenfenxi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(142)))), ((int)(((byte)(97)))));
            this.ToolStripMenuItemShuiwenfenxi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemShuiwenfenxi.Name = "ToolStripMenuItemShuiwenfenxi";
            this.ToolStripMenuItemShuiwenfenxi.Size = new System.Drawing.Size(230, 28);
            this.ToolStripMenuItemShuiwenfenxi.Text = "水文分析";
            this.ToolStripMenuItemShuiwenfenxi.Click += new System.EventHandler(this.水文分析ToolStripMenuItem_Click);
            // 
            // ToolStripMenuItemBangzhuwenjian
            // 
            this.ToolStripMenuItemBangzhuwenjian.BackColor = System.Drawing.Color.Transparent;
            this.ToolStripMenuItemBangzhuwenjian.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItemJianyi,
            this.ToolStripMenuItemZhongzhijianyi,
            this.ToolStripMenuItemBangzhushipin});
            this.ToolStripMenuItemBangzhuwenjian.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ToolStripMenuItemBangzhuwenjian.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemBangzhuwenjian.Name = "ToolStripMenuItemBangzhuwenjian";
            this.ToolStripMenuItemBangzhuwenjian.Size = new System.Drawing.Size(122, 28);
            this.ToolStripMenuItemBangzhuwenjian.Text = "帮助文件";
            // 
            // ToolStripMenuItemJianyi
            // 
            this.ToolStripMenuItemJianyi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(142)))), ((int)(((byte)(97)))));
            this.ToolStripMenuItemJianyi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemJianyi.Name = "ToolStripMenuItemJianyi";
            this.ToolStripMenuItemJianyi.Size = new System.Drawing.Size(180, 28);
            this.ToolStripMenuItemJianyi.Text = "推荐权重";
            // 
            // ToolStripMenuItemZhongzhijianyi
            // 
            this.ToolStripMenuItemZhongzhijianyi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(142)))), ((int)(((byte)(97)))));
            this.ToolStripMenuItemZhongzhijianyi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemZhongzhijianyi.Name = "ToolStripMenuItemZhongzhijianyi";
            this.ToolStripMenuItemZhongzhijianyi.Size = new System.Drawing.Size(180, 28);
            this.ToolStripMenuItemZhongzhijianyi.Text = "种植建议";
            this.ToolStripMenuItemZhongzhijianyi.Click += new System.EventHandler(this.种植建议ToolStripMenuItem_Click);
            // 
            // ToolStripMenuItemBangzhushipin
            // 
            this.ToolStripMenuItemBangzhushipin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(142)))), ((int)(((byte)(97)))));
            this.ToolStripMenuItemBangzhushipin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(248)))), ((int)(((byte)(235)))));
            this.ToolStripMenuItemBangzhushipin.Name = "ToolStripMenuItemBangzhushipin";
            this.ToolStripMenuItemBangzhushipin.Size = new System.Drawing.Size(180, 28);
            this.ToolStripMenuItemBangzhushipin.Text = "帮助视频";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.panelShuqian);
            this.splitContainer2.Panel2.Controls.Add(this.statusStrip1);
            this.splitContainer2.Panel2.Controls.Add(this.axMapControlZhu);
            this.splitContainer2.Panel2.Controls.Add(this.axLicenseControl);
            this.splitContainer2.Size = new System.Drawing.Size(1502, 971);
            this.splitContainer2.SplitterDistance = 288;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.axMapControlYingyan);
            this.splitContainer3.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer3_Panel1_Paint);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.groupBoxJichumianban);
            this.splitContainer3.Size = new System.Drawing.Size(288, 971);
            this.splitContainer3.SplitterDistance = 201;
            this.splitContainer3.SplitterWidth = 5;
            this.splitContainer3.TabIndex = 0;
            // 
            // axMapControlYingyan
            // 
            this.axMapControlYingyan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axMapControlYingyan.Location = new System.Drawing.Point(0, 0);
            this.axMapControlYingyan.Margin = new System.Windows.Forms.Padding(4);
            this.axMapControlYingyan.Name = "axMapControlYingyan";
            this.axMapControlYingyan.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMapControlYingyan.OcxState")));
            this.axMapControlYingyan.Size = new System.Drawing.Size(288, 201);
            this.axMapControlYingyan.TabIndex = 0;
            this.axMapControlYingyan.OnMouseDown += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseDownEventHandler(this.axMapControl2_OnMouseDown);
            this.axMapControlYingyan.OnMapReplaced += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMapReplacedEventHandler(this.axMapControl2_OnMapReplaced);
            // 
            // groupBoxJichumianban
            // 
            this.groupBoxJichumianban.BackColor = System.Drawing.Color.White;
            this.groupBoxJichumianban.Controls.Add(this.PanelJiangshuichaxun);
            this.groupBoxJichumianban.Controls.Add(this.buttonJiangshuichaxun);
            this.groupBoxJichumianban.Controls.Add(this.PanelHeliuxianzhuang);
            this.groupBoxJichumianban.Controls.Add(this.buttonHeliuxianzhuang);
            this.groupBoxJichumianban.Controls.Add(this.PanelZhibeifenbu);
            this.groupBoxJichumianban.Controls.Add(this.ButtonZhibeifenbu);
            this.groupBoxJichumianban.Controls.Add(this.PanelJichutuceng);
            this.groupBoxJichumianban.Controls.Add(this.ButtonGuanlituceng);
            this.groupBoxJichumianban.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxJichumianban.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBoxJichumianban.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(87)))), ((int)(((byte)(48)))));
            this.groupBoxJichumianban.Location = new System.Drawing.Point(0, 0);
            this.groupBoxJichumianban.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxJichumianban.Name = "groupBoxJichumianban";
            this.groupBoxJichumianban.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxJichumianban.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBoxJichumianban.Size = new System.Drawing.Size(288, 765);
            this.groupBoxJichumianban.TabIndex = 0;
            this.groupBoxJichumianban.TabStop = false;
            this.groupBoxJichumianban.Text = "基础面板";
            this.groupBoxJichumianban.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // PanelJichutuceng
            // 
            this.PanelJichutuceng.BackColor = System.Drawing.Color.White;
            this.PanelJichutuceng.Controls.Add(this.button1);
            this.PanelJichutuceng.Controls.Add(this.button3);
            this.PanelJichutuceng.Controls.Add(this.button2);
            this.PanelJichutuceng.Controls.Add(this.ButtonDaolu);
            this.PanelJichutuceng.Controls.Add(this.ButtonXingzhengfanwei);
            this.PanelJichutuceng.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelJichutuceng.Location = new System.Drawing.Point(4, 77);
            this.PanelJichutuceng.Name = "PanelJichutuceng";
            this.PanelJichutuceng.Size = new System.Drawing.Size(280, 159);
            this.PanelJichutuceng.TabIndex = 11;
            this.PanelJichutuceng.Visible = false;
            // 
            // ButtonDaolu
            // 
            this.ButtonDaolu.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButtonDaolu.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonDaolu.Location = new System.Drawing.Point(0, 30);
            this.ButtonDaolu.Name = "ButtonDaolu";
            this.ButtonDaolu.Size = new System.Drawing.Size(280, 30);
            this.ButtonDaolu.TabIndex = 9;
            this.ButtonDaolu.Text = "道路";
            this.ButtonDaolu.UseVisualStyleBackColor = true;
            this.ButtonDaolu.Click += new System.EventHandler(this.ButtonDaolu_Click);
            // 
            // ButtonXingzhengfanwei
            // 
            this.ButtonXingzhengfanwei.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButtonXingzhengfanwei.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButtonXingzhengfanwei.Location = new System.Drawing.Point(0, 0);
            this.ButtonXingzhengfanwei.Name = "ButtonXingzhengfanwei";
            this.ButtonXingzhengfanwei.Size = new System.Drawing.Size(280, 30);
            this.ButtonXingzhengfanwei.TabIndex = 8;
            this.ButtonXingzhengfanwei.Text = "行政范围";
            this.ButtonXingzhengfanwei.UseVisualStyleBackColor = true;
            this.ButtonXingzhengfanwei.Click += new System.EventHandler(this.button11_Click);
            // 
            // ButtonGuanlituceng
            // 
            this.ButtonGuanlituceng.BackColor = System.Drawing.Color.DarkGreen;
            this.ButtonGuanlituceng.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ButtonGuanlituceng.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButtonGuanlituceng.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ButtonGuanlituceng.ForeColor = System.Drawing.Color.White;
            this.ButtonGuanlituceng.Image = ((System.Drawing.Image)(resources.GetObject("ButtonGuanlituceng.Image")));
            this.ButtonGuanlituceng.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonGuanlituceng.Location = new System.Drawing.Point(4, 32);
            this.ButtonGuanlituceng.Name = "ButtonGuanlituceng";
            this.ButtonGuanlituceng.Size = new System.Drawing.Size(280, 45);
            this.ButtonGuanlituceng.TabIndex = 12;
            this.ButtonGuanlituceng.Text = "基础图层";
            this.ButtonGuanlituceng.UseVisualStyleBackColor = false;
            this.ButtonGuanlituceng.Click += new System.EventHandler(this.button12_Click);
            // 
            // panelShuqian
            // 
            this.panelShuqian.Controls.Add(this.buttonYichusuoxuan);
            this.panelShuqian.Controls.Add(this.buttonYichuquanbu);
            this.panelShuqian.Controls.Add(this.buttonDingwei);
            this.panelShuqian.Controls.Add(this.listBoxShuqian);
            this.panelShuqian.Location = new System.Drawing.Point(31, 98);
            this.panelShuqian.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelShuqian.Name = "panelShuqian";
            this.panelShuqian.Size = new System.Drawing.Size(267, 285);
            this.panelShuqian.TabIndex = 4;
            this.panelShuqian.Visible = false;
            // 
            // buttonYichusuoxuan
            // 
            this.buttonYichusuoxuan.Location = new System.Drawing.Point(69, 240);
            this.buttonYichusuoxuan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonYichusuoxuan.Name = "buttonYichusuoxuan";
            this.buttonYichusuoxuan.Size = new System.Drawing.Size(120, 28);
            this.buttonYichusuoxuan.TabIndex = 3;
            this.buttonYichusuoxuan.Text = "移除所选";
            this.buttonYichusuoxuan.UseVisualStyleBackColor = true;
            this.buttonYichusuoxuan.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonYichuquanbu
            // 
            this.buttonYichuquanbu.Location = new System.Drawing.Point(69, 192);
            this.buttonYichuquanbu.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonYichuquanbu.Name = "buttonYichuquanbu";
            this.buttonYichuquanbu.Size = new System.Drawing.Size(120, 30);
            this.buttonYichuquanbu.TabIndex = 2;
            this.buttonYichuquanbu.Text = "移除全部";
            this.buttonYichuquanbu.UseVisualStyleBackColor = true;
            this.buttonYichuquanbu.Click += new System.EventHandler(this.button6_Click);
            // 
            // buttonDingwei
            // 
            this.buttonDingwei.Location = new System.Drawing.Point(69, 144);
            this.buttonDingwei.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonDingwei.Name = "buttonDingwei";
            this.buttonDingwei.Size = new System.Drawing.Size(120, 32);
            this.buttonDingwei.TabIndex = 1;
            this.buttonDingwei.Text = "定位至";
            this.buttonDingwei.UseVisualStyleBackColor = true;
            this.buttonDingwei.Click += new System.EventHandler(this.button5_Click);
            // 
            // listBoxShuqian
            // 
            this.listBoxShuqian.FormattingEnabled = true;
            this.listBoxShuqian.ItemHeight = 15;
            this.listBoxShuqian.Location = new System.Drawing.Point(23, 16);
            this.listBoxShuqian.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listBoxShuqian.Name = "listBoxShuqian";
            this.listBoxShuqian.Size = new System.Drawing.Size(221, 124);
            this.listBoxShuqian.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 949);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 13, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1209, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // axMapControlZhu
            // 
            this.axMapControlZhu.Location = new System.Drawing.Point(0, 0);
            this.axMapControlZhu.Margin = new System.Windows.Forms.Padding(4);
            this.axMapControlZhu.Name = "axMapControlZhu";
            this.axMapControlZhu.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMapControlZhu.OcxState")));
            this.axMapControlZhu.Size = new System.Drawing.Size(1209, 968);
            this.axMapControlZhu.TabIndex = 2;
            this.axMapControlZhu.OnMouseDown += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseDownEventHandler(this.axMapControl1_OnMouseDown);
            this.axMapControlZhu.OnMouseMove += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseMoveEventHandler(this.axMapControl1_OnMouseMove);
            this.axMapControlZhu.OnDoubleClick += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnDoubleClickEventHandler(this.axMapControl1_OnDoubleClick);
            this.axMapControlZhu.OnMapReplaced += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMapReplacedEventHandler(this.axMapControl1_OnMapReplaced);
            // 
            // axLicenseControl
            // 
            this.axLicenseControl.Enabled = true;
            this.axLicenseControl.Location = new System.Drawing.Point(788, 433);
            this.axLicenseControl.Margin = new System.Windows.Forms.Padding(4);
            this.axLicenseControl.Name = "axLicenseControl";
            this.axLicenseControl.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axLicenseControl.OcxState")));
            this.axLicenseControl.Size = new System.Drawing.Size(32, 32);
            this.axLicenseControl.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.ForestGreen;
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.menuStrip1);
            this.panel3.Location = new System.Drawing.Point(77, 23);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1439, 54);
            this.panel3.TabIndex = 1;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.YellowGreen;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(0, -4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(100, 81);
            this.panel2.TabIndex = 0;
            // 
            // PanelJiangshuichaxun
            // 
            this.PanelJiangshuichaxun.BackColor = System.Drawing.Color.White;
            this.PanelJiangshuichaxun.Controls.Add(this.buttonQihouxinxi);
            this.PanelJiangshuichaxun.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelJiangshuichaxun.Location = new System.Drawing.Point(4, 611);
            this.PanelJiangshuichaxun.Name = "PanelJiangshuichaxun";
            this.PanelJiangshuichaxun.Size = new System.Drawing.Size(280, 120);
            this.PanelJiangshuichaxun.TabIndex = 18;
            this.PanelJiangshuichaxun.Visible = false;
            // 
            // PanelHeliuxianzhuang
            // 
            this.PanelHeliuxianzhuang.BackColor = System.Drawing.Color.White;
            this.PanelHeliuxianzhuang.Controls.Add(this.buttonHeliufenbu);
            this.PanelHeliuxianzhuang.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelHeliuxianzhuang.Location = new System.Drawing.Point(4, 446);
            this.PanelHeliuxianzhuang.Name = "PanelHeliuxianzhuang";
            this.PanelHeliuxianzhuang.Size = new System.Drawing.Size(280, 120);
            this.PanelHeliuxianzhuang.TabIndex = 15;
            this.PanelHeliuxianzhuang.Visible = false;
            // 
            // PanelZhibeifenbu
            // 
            this.PanelZhibeifenbu.BackColor = System.Drawing.Color.White;
            this.PanelZhibeifenbu.Controls.Add(this.buttonFugaishuju);
            this.PanelZhibeifenbu.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelZhibeifenbu.Location = new System.Drawing.Point(4, 281);
            this.PanelZhibeifenbu.Name = "PanelZhibeifenbu";
            this.PanelZhibeifenbu.Size = new System.Drawing.Size(280, 120);
            this.PanelZhibeifenbu.TabIndex = 13;
            this.PanelZhibeifenbu.Visible = false;
            // 
            // buttonQihouxinxi
            // 
            this.buttonQihouxinxi.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonQihouxinxi.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQihouxinxi.Location = new System.Drawing.Point(0, 0);
            this.buttonQihouxinxi.Name = "buttonQihouxinxi";
            this.buttonQihouxinxi.Size = new System.Drawing.Size(280, 30);
            this.buttonQihouxinxi.TabIndex = 9;
            this.buttonQihouxinxi.Text = "气候信息";
            this.buttonQihouxinxi.UseVisualStyleBackColor = true;
            // 
            // buttonHeliufenbu
            // 
            this.buttonHeliufenbu.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonHeliufenbu.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHeliufenbu.Location = new System.Drawing.Point(0, 0);
            this.buttonHeliufenbu.Name = "buttonHeliufenbu";
            this.buttonHeliufenbu.Size = new System.Drawing.Size(280, 30);
            this.buttonHeliufenbu.TabIndex = 9;
            this.buttonHeliufenbu.Text = "河流分布";
            this.buttonHeliufenbu.UseVisualStyleBackColor = true;
            this.buttonHeliufenbu.Click += new System.EventHandler(this.buttonHeliufenbu_Click);
            // 
            // buttonFugaishuju
            // 
            this.buttonFugaishuju.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonFugaishuju.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonFugaishuju.Location = new System.Drawing.Point(0, 0);
            this.buttonFugaishuju.Name = "buttonFugaishuju";
            this.buttonFugaishuju.Size = new System.Drawing.Size(280, 30);
            this.buttonFugaishuju.TabIndex = 9;
            this.buttonFugaishuju.Text = "覆盖范围";
            this.buttonFugaishuju.UseVisualStyleBackColor = true;
            this.buttonFugaishuju.Click += new System.EventHandler(this.button10_Click);
            // 
            // buttonJiangshuichaxun
            // 
            this.buttonJiangshuichaxun.BackColor = System.Drawing.Color.DarkGreen;
            this.buttonJiangshuichaxun.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonJiangshuichaxun.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonJiangshuichaxun.ForeColor = System.Drawing.Color.White;
            this.buttonJiangshuichaxun.Image = ((System.Drawing.Image)(resources.GetObject("buttonJiangshuichaxun.Image")));
            this.buttonJiangshuichaxun.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonJiangshuichaxun.Location = new System.Drawing.Point(4, 566);
            this.buttonJiangshuichaxun.Name = "buttonJiangshuichaxun";
            this.buttonJiangshuichaxun.Size = new System.Drawing.Size(280, 45);
            this.buttonJiangshuichaxun.TabIndex = 17;
            this.buttonJiangshuichaxun.Text = "降水查询";
            this.buttonJiangshuichaxun.UseVisualStyleBackColor = false;
            this.buttonJiangshuichaxun.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // buttonHeliuxianzhuang
            // 
            this.buttonHeliuxianzhuang.BackColor = System.Drawing.Color.DarkGreen;
            this.buttonHeliuxianzhuang.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonHeliuxianzhuang.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHeliuxianzhuang.ForeColor = System.Drawing.Color.White;
            this.buttonHeliuxianzhuang.Image = ((System.Drawing.Image)(resources.GetObject("buttonHeliuxianzhuang.Image")));
            this.buttonHeliuxianzhuang.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHeliuxianzhuang.Location = new System.Drawing.Point(4, 401);
            this.buttonHeliuxianzhuang.Name = "buttonHeliuxianzhuang";
            this.buttonHeliuxianzhuang.Size = new System.Drawing.Size(280, 45);
            this.buttonHeliuxianzhuang.TabIndex = 16;
            this.buttonHeliuxianzhuang.Text = "河流现状";
            this.buttonHeliuxianzhuang.UseVisualStyleBackColor = false;
            this.buttonHeliuxianzhuang.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // ButtonZhibeifenbu
            // 
            this.ButtonZhibeifenbu.BackColor = System.Drawing.Color.DarkGreen;
            this.ButtonZhibeifenbu.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButtonZhibeifenbu.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ButtonZhibeifenbu.ForeColor = System.Drawing.Color.White;
            this.ButtonZhibeifenbu.Image = ((System.Drawing.Image)(resources.GetObject("ButtonZhibeifenbu.Image")));
            this.ButtonZhibeifenbu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonZhibeifenbu.Location = new System.Drawing.Point(4, 236);
            this.ButtonZhibeifenbu.Name = "ButtonZhibeifenbu";
            this.ButtonZhibeifenbu.Size = new System.Drawing.Size(280, 45);
            this.ButtonZhibeifenbu.TabIndex = 14;
            this.ButtonZhibeifenbu.Text = "植被分布";
            this.ButtonZhibeifenbu.UseVisualStyleBackColor = false;
            this.ButtonZhibeifenbu.Click += new System.EventHandler(this.植被分布_Click);
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(0, 60);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(280, 30);
            this.button2.TabIndex = 11;
            this.button2.Text = "植被覆盖";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(0, 90);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(280, 30);
            this.button3.TabIndex = 12;
            this.button3.Text = "河流分布";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(0, 120);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(280, 30);
            this.button1.TabIndex = 13;
            this.button1.Text = "气候查询";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.ForestGreen;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox2.Location = new System.Drawing.Point(29, 15);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(169, 27);
            this.textBox2.TabIndex = 5;
            this.textBox2.TabStop = false;
            this.textBox2.Text = "农林信息系统";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1528, 1055);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "农林信息系统";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axMapControlYingyan)).EndInit();
            this.groupBoxJichumianban.ResumeLayout(false);
            this.PanelJichutuceng.ResumeLayout(false);
            this.panelShuqian.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axMapControlZhu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.PanelJiangshuichaxun.ResumeLayout(false);
            this.PanelHeliuxianzhuang.ResumeLayout(false);
            this.PanelZhibeifenbu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private ESRI.ArcGIS.Controls.AxLicenseControl axLicenseControl;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemShujuchuangkou;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemZhuangtixinxi;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemZhubeishiyixing;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemTuranqinranxing;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemDaqiwuranjiance;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemShuiwenfenxi;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBangzhuwenjian;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemJianyi;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemZhongzhijianyi;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItemBangzhushipin;
        private ESRI.ArcGIS.Controls.AxMapControl axMapControlZhu;
        private ESRI.ArcGIS.Controls.AxMapControl axMapControlYingyan;
        private System.Windows.Forms.GroupBox groupBoxJichumianban;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Panel panelShuqian;
        private System.Windows.Forms.Button buttonYichusuoxuan;
        private System.Windows.Forms.Button buttonYichuquanbu;
        private System.Windows.Forms.Button buttonDingwei;
        private System.Windows.Forms.ListBox listBoxShuqian;
        private System.Windows.Forms.Button ButtonGuanlituceng;
        private System.Windows.Forms.Panel PanelJichutuceng;
        private System.Windows.Forms.Button ButtonDaolu;
        private System.Windows.Forms.Button ButtonXingzhengfanwei;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel PanelJiangshuichaxun;
        private System.Windows.Forms.Button buttonQihouxinxi;
        private System.Windows.Forms.Button buttonJiangshuichaxun;
        private System.Windows.Forms.Panel PanelHeliuxianzhuang;
        private System.Windows.Forms.Button buttonHeliufenbu;
        private System.Windows.Forms.Button buttonHeliuxianzhuang;
        private System.Windows.Forms.Panel PanelZhibeifenbu;
        private System.Windows.Forms.Button buttonFugaishuju;
        private System.Windows.Forms.Button ButtonZhibeifenbu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;


    }
}

